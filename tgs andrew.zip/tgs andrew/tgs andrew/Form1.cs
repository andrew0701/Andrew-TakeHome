namespace tgs_andrew
{
    public partial class Form1 : Form
    {
        string[] kata = new string[5];
        char[] kata2 = new char[5];
        int count = 0;
        int baru = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void tb_1_TextChanged(object sender, EventArgs e)
        {
            kata[0] = tb_1.Text;
        }

        private void tb2_TextChanged(object sender, EventArgs e)
        {
            kata[1] = tb2.Text;
        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            kata[2] = tb3.Text;
        }

        private void tb4_TextChanged(object sender, EventArgs e)
        {
            kata[3] = tb4.Text;
        }

        private void tb5_TextChanged(object sender, EventArgs e)
        {
            kata[4] = tb5.Text;
        }

        private void bt_play_Click(object sender, EventArgs e)
        {
            if (kata[0].Length != 5 || kata[1].Length != 5 || kata[2].Length != 5 || kata[3].Length != 5 || kata[4].Length != 5)
            {
                MessageBox.Show("There's still an error");
                
            }
            else
            {
                MessageBox.Show("Lets Play");
                pnl.Top = 1000;
                pnl_kb.Visible = true;
                Random random = new Random();
                int indeksAcak = random.Next(0, 5);
                string kataWordle = kata[indeksAcak];
                kataWordle = kataWordle.ToLower();

                int hitung = 0;
                foreach (char c in kataWordle)
                {
                    kata2[hitung] = c;
                    hitung++;
                }
                foreach (char c in kata2)
                {
                    lb_isi.Text += c;
                }
            }
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pnl.Top = 48;
        }

        private void lb_isi_Click(object sender, EventArgs e)
        {

        }

        private void bt_Q_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'q')
                {
                    string key = "Q";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_w_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'w')
                {
                    string key = "W";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_E_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'e')
                {
                    string key = "E";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_R_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'r')
                {
                    string key = "R";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_T_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 't')
                {
                    string key = "T";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_Y_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'y')
                {
                    string key = "Y";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_U_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'u')
                {
                    string key = "U";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_I_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'i')
                {
                    string key = "I";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_O_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'o')
                {
                    string key = "O";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_P_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'p')
                {
                    string key = "P";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_A_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'a')
                {
                    string key = "A";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_S_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 's')
                {
                    string key = "S";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_D_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'd')
                {
                    string key = "D";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_F_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'f')
                {
                    string key = "F";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_G_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'g')
                {
                    string key = "G";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_H_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'h')
                {
                    string key = "H";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_J_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'j')
                {
                    string key = "J";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_K_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'k')
                {
                    string key = "K";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_L_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'l')
                {
                    string key = "L";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_Z_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'z')
                {
                    string key = "Z";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_X_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'x')
                {
                    string key = "X";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_C_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'c')
                {
                    string key = "C";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_V_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'v')
                {
                    string key = "V";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_B_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'b')
                {
                    string key = "B";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_N_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'n')
                {
                    string key = "N";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }

        private void bt_M_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (kata2[i] == 'm')
                {
                    string key = "M";
                    if (count == 0)
                    {
                        lb_isi_1.Text = key;
                    }
                    else if (count == 1)
                    {
                        lb_isi_2.Text = key;
                    }
                    else if (count == 2)
                    {
                        lb_isi_3.Text = key;
                    }
                    else if (count == 3)
                    {
                        lb_isi_4.Text = key;
                    }
                    else if (count == 4)
                    {
                        lb_isi_5.Text = key;
                    }
                    count++;
                    break;
                }
            }
            if (count == 5)
            {
                MessageBox.Show("menang");
            }
        }
    }
}
