﻿namespace tgs_andrew
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lb_word1 = new Label();
            lb_word2 = new Label();
            lb_word3 = new Label();
            lb_word4 = new Label();
            lb_word5 = new Label();
            tb_1 = new TextBox();
            tb2 = new TextBox();
            tb3 = new TextBox();
            tb4 = new TextBox();
            tb5 = new TextBox();
            bt_play = new Button();
            pnl = new Panel();
            pnl_kb = new Panel();
            lb_isi = new Label();
            lb_isi_5 = new Label();
            lb_isi_4 = new Label();
            lb_isi_3 = new Label();
            lb_isi_2 = new Label();
            lb_isi_1 = new Label();
            lb_isi1 = new Label();
            bt_M = new Button();
            bt_N = new Button();
            bt_B = new Button();
            bt_V = new Button();
            bt_C = new Button();
            bt_Z = new Button();
            bt_X = new Button();
            bt_A = new Button();
            bt_S = new Button();
            bt_D = new Button();
            bt_F = new Button();
            bt_G = new Button();
            bt_L = new Button();
            bt_K = new Button();
            bt_J = new Button();
            bt_H = new Button();
            bt_P = new Button();
            bt_w = new Button();
            bt_E = new Button();
            bt_R = new Button();
            bt_T = new Button();
            bt_O = new Button();
            bt_I = new Button();
            bt_U = new Button();
            bt_Y = new Button();
            bt_Q = new Button();
            pnl.SuspendLayout();
            pnl_kb.SuspendLayout();
            SuspendLayout();
            // 
            // lb_word1
            // 
            lb_word1.AutoSize = true;
            lb_word1.Location = new Point(3, 0);
            lb_word1.Name = "lb_word1";
            lb_word1.Size = new Size(58, 20);
            lb_word1.TabIndex = 0;
            lb_word1.Text = "word 1:";
            // 
            // lb_word2
            // 
            lb_word2.AutoSize = true;
            lb_word2.Location = new Point(3, 30);
            lb_word2.Name = "lb_word2";
            lb_word2.Size = new Size(58, 20);
            lb_word2.TabIndex = 1;
            lb_word2.Text = "word 2:";
            // 
            // lb_word3
            // 
            lb_word3.AutoSize = true;
            lb_word3.Location = new Point(3, 60);
            lb_word3.Name = "lb_word3";
            lb_word3.Size = new Size(58, 20);
            lb_word3.TabIndex = 2;
            lb_word3.Text = "word 3:";
            // 
            // lb_word4
            // 
            lb_word4.AutoSize = true;
            lb_word4.Location = new Point(3, 91);
            lb_word4.Name = "lb_word4";
            lb_word4.Size = new Size(58, 20);
            lb_word4.TabIndex = 3;
            lb_word4.Text = "word 4:";
            // 
            // lb_word5
            // 
            lb_word5.AutoSize = true;
            lb_word5.Location = new Point(3, 123);
            lb_word5.Name = "lb_word5";
            lb_word5.Size = new Size(58, 20);
            lb_word5.TabIndex = 4;
            lb_word5.Text = "word 5:";
            // 
            // tb_1
            // 
            tb_1.Location = new Point(85, -3);
            tb_1.Name = "tb_1";
            tb_1.Size = new Size(125, 27);
            tb_1.TabIndex = 5;
            tb_1.TextChanged += tb_1_TextChanged;
            // 
            // tb2
            // 
            tb2.Location = new Point(85, 30);
            tb2.Name = "tb2";
            tb2.Size = new Size(125, 27);
            tb2.TabIndex = 6;
            tb2.TextChanged += tb2_TextChanged;
            // 
            // tb3
            // 
            tb3.Location = new Point(85, 63);
            tb3.Name = "tb3";
            tb3.Size = new Size(125, 27);
            tb3.TabIndex = 7;
            tb3.TextChanged += textBox3_TextChanged;
            // 
            // tb4
            // 
            tb4.Location = new Point(85, 96);
            tb4.Name = "tb4";
            tb4.Size = new Size(125, 27);
            tb4.TabIndex = 8;
            tb4.TextChanged += tb4_TextChanged;
            // 
            // tb5
            // 
            tb5.Location = new Point(85, 129);
            tb5.Name = "tb5";
            tb5.Size = new Size(125, 27);
            tb5.TabIndex = 9;
            tb5.TextChanged += tb5_TextChanged;
            // 
            // bt_play
            // 
            bt_play.Location = new Point(95, 171);
            bt_play.Name = "bt_play";
            bt_play.Size = new Size(94, 29);
            bt_play.TabIndex = 10;
            bt_play.Text = "Play!";
            bt_play.UseVisualStyleBackColor = true;
            bt_play.Click += bt_play_Click;
            // 
            // pnl
            // 
            pnl.Controls.Add(lb_word1);
            pnl.Controls.Add(bt_play);
            pnl.Controls.Add(lb_word2);
            pnl.Controls.Add(tb5);
            pnl.Controls.Add(lb_word3);
            pnl.Controls.Add(tb4);
            pnl.Controls.Add(lb_word4);
            pnl.Controls.Add(tb3);
            pnl.Controls.Add(lb_word5);
            pnl.Controls.Add(tb2);
            pnl.Controls.Add(tb_1);
            pnl.Location = new Point(12, 12);
            pnl.Name = "pnl";
            pnl.Size = new Size(270, 210);
            pnl.TabIndex = 11;
            // 
            // pnl_kb
            // 
            pnl_kb.Controls.Add(lb_isi);
            pnl_kb.Controls.Add(lb_isi_5);
            pnl_kb.Controls.Add(lb_isi_4);
            pnl_kb.Controls.Add(lb_isi_3);
            pnl_kb.Controls.Add(lb_isi_2);
            pnl_kb.Controls.Add(lb_isi_1);
            pnl_kb.Controls.Add(lb_isi1);
            pnl_kb.Controls.Add(bt_M);
            pnl_kb.Controls.Add(bt_N);
            pnl_kb.Controls.Add(bt_B);
            pnl_kb.Controls.Add(bt_V);
            pnl_kb.Controls.Add(bt_C);
            pnl_kb.Controls.Add(bt_Z);
            pnl_kb.Controls.Add(bt_X);
            pnl_kb.Controls.Add(bt_A);
            pnl_kb.Controls.Add(bt_S);
            pnl_kb.Controls.Add(bt_D);
            pnl_kb.Controls.Add(bt_F);
            pnl_kb.Controls.Add(bt_G);
            pnl_kb.Controls.Add(bt_L);
            pnl_kb.Controls.Add(bt_K);
            pnl_kb.Controls.Add(bt_J);
            pnl_kb.Controls.Add(bt_H);
            pnl_kb.Controls.Add(bt_P);
            pnl_kb.Controls.Add(bt_w);
            pnl_kb.Controls.Add(bt_E);
            pnl_kb.Controls.Add(bt_R);
            pnl_kb.Controls.Add(bt_T);
            pnl_kb.Controls.Add(bt_O);
            pnl_kb.Controls.Add(bt_I);
            pnl_kb.Controls.Add(bt_U);
            pnl_kb.Controls.Add(bt_Y);
            pnl_kb.Controls.Add(bt_Q);
            pnl_kb.Location = new Point(12, 42);
            pnl_kb.Name = "pnl_kb";
            pnl_kb.Size = new Size(773, 400);
            pnl_kb.TabIndex = 12;
            pnl_kb.Visible = false;
            // 
            // lb_isi
            // 
            lb_isi.AutoSize = true;
            lb_isi.Location = new Point(644, 42);
            lb_isi.Name = "lb_isi";
            lb_isi.Size = new Size(0, 20);
            lb_isi.TabIndex = 74;
            lb_isi.Click += lb_isi_Click;
            // 
            // lb_isi_5
            // 
            lb_isi_5.AutoSize = true;
            lb_isi_5.Location = new Point(412, 86);
            lb_isi_5.Name = "lb_isi_5";
            lb_isi_5.Size = new Size(27, 20);
            lb_isi_5.TabIndex = 73;
            lb_isi_5.Text = "___";
            // 
            // lb_isi_4
            // 
            lb_isi_4.AutoSize = true;
            lb_isi_4.Location = new Point(374, 86);
            lb_isi_4.Name = "lb_isi_4";
            lb_isi_4.Size = new Size(27, 20);
            lb_isi_4.TabIndex = 72;
            lb_isi_4.Text = "___";
            // 
            // lb_isi_3
            // 
            lb_isi_3.AutoSize = true;
            lb_isi_3.Location = new Point(341, 86);
            lb_isi_3.Name = "lb_isi_3";
            lb_isi_3.Size = new Size(27, 20);
            lb_isi_3.TabIndex = 71;
            lb_isi_3.Text = "___";
            // 
            // lb_isi_2
            // 
            lb_isi_2.AutoSize = true;
            lb_isi_2.Location = new Point(308, 86);
            lb_isi_2.Name = "lb_isi_2";
            lb_isi_2.Size = new Size(27, 20);
            lb_isi_2.TabIndex = 70;
            lb_isi_2.Text = "___";
            // 
            // lb_isi_1
            // 
            lb_isi_1.AutoSize = true;
            lb_isi_1.Location = new Point(276, 86);
            lb_isi_1.Name = "lb_isi_1";
            lb_isi_1.Size = new Size(27, 20);
            lb_isi_1.TabIndex = 69;
            lb_isi_1.Text = "___";
            // 
            // lb_isi1
            // 
            lb_isi1.AutoSize = true;
            lb_isi1.Location = new Point(275, 86);
            lb_isi1.Name = "lb_isi1";
            lb_isi1.Size = new Size(27, 20);
            lb_isi1.TabIndex = 69;
            lb_isi1.Text = "___";
            // 
            // bt_M
            // 
            bt_M.Location = new Point(499, 305);
            bt_M.Name = "bt_M";
            bt_M.Size = new Size(50, 50);
            bt_M.TabIndex = 68;
            bt_M.Text = "M";
            bt_M.UseVisualStyleBackColor = true;
            bt_M.Click += bt_M_Click;
            // 
            // bt_N
            // 
            bt_N.Location = new Point(443, 305);
            bt_N.Name = "bt_N";
            bt_N.Size = new Size(50, 50);
            bt_N.TabIndex = 67;
            bt_N.Text = "N";
            bt_N.UseVisualStyleBackColor = true;
            bt_N.Click += bt_N_Click;
            // 
            // bt_B
            // 
            bt_B.Location = new Point(387, 305);
            bt_B.Name = "bt_B";
            bt_B.Size = new Size(50, 50);
            bt_B.TabIndex = 66;
            bt_B.Text = "B";
            bt_B.UseVisualStyleBackColor = true;
            bt_B.Click += bt_B_Click;
            // 
            // bt_V
            // 
            bt_V.Location = new Point(331, 305);
            bt_V.Name = "bt_V";
            bt_V.Size = new Size(50, 50);
            bt_V.TabIndex = 65;
            bt_V.Text = "V";
            bt_V.UseVisualStyleBackColor = true;
            bt_V.Click += bt_V_Click;
            // 
            // bt_C
            // 
            bt_C.Location = new Point(275, 305);
            bt_C.Name = "bt_C";
            bt_C.Size = new Size(50, 50);
            bt_C.TabIndex = 64;
            bt_C.Text = "C";
            bt_C.UseVisualStyleBackColor = true;
            bt_C.Click += bt_C_Click;
            // 
            // bt_Z
            // 
            bt_Z.Location = new Point(161, 305);
            bt_Z.Name = "bt_Z";
            bt_Z.Size = new Size(50, 50);
            bt_Z.TabIndex = 63;
            bt_Z.Text = "Z";
            bt_Z.UseVisualStyleBackColor = true;
            bt_Z.Click += bt_Z_Click;
            // 
            // bt_X
            // 
            bt_X.Location = new Point(219, 305);
            bt_X.Name = "bt_X";
            bt_X.Size = new Size(50, 50);
            bt_X.TabIndex = 62;
            bt_X.Text = "X";
            bt_X.UseVisualStyleBackColor = true;
            bt_X.Click += bt_X_Click;
            // 
            // bt_A
            // 
            bt_A.Location = new Point(132, 249);
            bt_A.Name = "bt_A";
            bt_A.Size = new Size(50, 50);
            bt_A.TabIndex = 61;
            bt_A.Text = "A";
            bt_A.UseVisualStyleBackColor = true;
            bt_A.Click += bt_A_Click;
            // 
            // bt_S
            // 
            bt_S.Location = new Point(188, 249);
            bt_S.Name = "bt_S";
            bt_S.Size = new Size(50, 50);
            bt_S.TabIndex = 60;
            bt_S.Text = "S";
            bt_S.UseVisualStyleBackColor = true;
            bt_S.Click += bt_S_Click;
            // 
            // bt_D
            // 
            bt_D.Location = new Point(244, 249);
            bt_D.Name = "bt_D";
            bt_D.Size = new Size(50, 50);
            bt_D.TabIndex = 59;
            bt_D.Text = "D";
            bt_D.UseVisualStyleBackColor = true;
            bt_D.Click += bt_D_Click;
            // 
            // bt_F
            // 
            bt_F.Location = new Point(300, 249);
            bt_F.Name = "bt_F";
            bt_F.Size = new Size(50, 50);
            bt_F.TabIndex = 58;
            bt_F.Text = "F";
            bt_F.UseVisualStyleBackColor = true;
            bt_F.Click += bt_F_Click;
            // 
            // bt_G
            // 
            bt_G.Location = new Point(356, 249);
            bt_G.Name = "bt_G";
            bt_G.Size = new Size(50, 50);
            bt_G.TabIndex = 57;
            bt_G.Text = "G";
            bt_G.UseVisualStyleBackColor = true;
            bt_G.Click += bt_G_Click;
            // 
            // bt_L
            // 
            bt_L.Location = new Point(580, 249);
            bt_L.Name = "bt_L";
            bt_L.Size = new Size(50, 50);
            bt_L.TabIndex = 56;
            bt_L.Text = "L";
            bt_L.UseVisualStyleBackColor = true;
            bt_L.Click += bt_L_Click;
            // 
            // bt_K
            // 
            bt_K.Location = new Point(524, 249);
            bt_K.Name = "bt_K";
            bt_K.Size = new Size(50, 50);
            bt_K.TabIndex = 55;
            bt_K.Text = "K";
            bt_K.UseVisualStyleBackColor = true;
            bt_K.Click += bt_K_Click;
            // 
            // bt_J
            // 
            bt_J.Location = new Point(468, 249);
            bt_J.Name = "bt_J";
            bt_J.Size = new Size(50, 50);
            bt_J.TabIndex = 54;
            bt_J.Text = "J";
            bt_J.UseVisualStyleBackColor = true;
            bt_J.Click += bt_J_Click;
            // 
            // bt_H
            // 
            bt_H.Location = new Point(412, 249);
            bt_H.Name = "bt_H";
            bt_H.Size = new Size(50, 50);
            bt_H.TabIndex = 53;
            bt_H.Text = "H";
            bt_H.UseVisualStyleBackColor = true;
            bt_H.Click += bt_H_Click;
            // 
            // bt_P
            // 
            bt_P.Location = new Point(611, 193);
            bt_P.Name = "bt_P";
            bt_P.Size = new Size(50, 50);
            bt_P.TabIndex = 52;
            bt_P.Text = "P";
            bt_P.UseVisualStyleBackColor = true;
            bt_P.Click += bt_P_Click;
            // 
            // bt_w
            // 
            bt_w.Location = new Point(163, 193);
            bt_w.Name = "bt_w";
            bt_w.Size = new Size(50, 50);
            bt_w.TabIndex = 51;
            bt_w.Text = "W";
            bt_w.UseVisualStyleBackColor = true;
            bt_w.Click += bt_w_Click;
            // 
            // bt_E
            // 
            bt_E.Location = new Point(219, 193);
            bt_E.Name = "bt_E";
            bt_E.Size = new Size(50, 50);
            bt_E.TabIndex = 50;
            bt_E.Text = "E";
            bt_E.UseVisualStyleBackColor = true;
            bt_E.Click += bt_E_Click;
            // 
            // bt_R
            // 
            bt_R.Location = new Point(275, 193);
            bt_R.Name = "bt_R";
            bt_R.Size = new Size(50, 50);
            bt_R.TabIndex = 49;
            bt_R.Text = "R";
            bt_R.UseVisualStyleBackColor = true;
            bt_R.Click += bt_R_Click;
            // 
            // bt_T
            // 
            bt_T.Location = new Point(331, 193);
            bt_T.Name = "bt_T";
            bt_T.Size = new Size(50, 50);
            bt_T.TabIndex = 48;
            bt_T.Text = "T";
            bt_T.UseVisualStyleBackColor = true;
            bt_T.Click += bt_T_Click;
            // 
            // bt_O
            // 
            bt_O.Location = new Point(555, 193);
            bt_O.Name = "bt_O";
            bt_O.Size = new Size(50, 50);
            bt_O.TabIndex = 47;
            bt_O.Text = "O";
            bt_O.UseVisualStyleBackColor = true;
            bt_O.Click += bt_O_Click;
            // 
            // bt_I
            // 
            bt_I.Location = new Point(499, 193);
            bt_I.Name = "bt_I";
            bt_I.Size = new Size(50, 50);
            bt_I.TabIndex = 46;
            bt_I.Text = "I";
            bt_I.UseVisualStyleBackColor = true;
            bt_I.Click += bt_I_Click;
            // 
            // bt_U
            // 
            bt_U.Location = new Point(443, 193);
            bt_U.Name = "bt_U";
            bt_U.Size = new Size(50, 50);
            bt_U.TabIndex = 45;
            bt_U.Text = "U";
            bt_U.UseVisualStyleBackColor = true;
            bt_U.Click += bt_U_Click;
            // 
            // bt_Y
            // 
            bt_Y.Location = new Point(387, 193);
            bt_Y.Name = "bt_Y";
            bt_Y.Size = new Size(50, 50);
            bt_Y.TabIndex = 44;
            bt_Y.Text = "Y";
            bt_Y.UseVisualStyleBackColor = true;
            bt_Y.Click += bt_Y_Click;
            // 
            // bt_Q
            // 
            bt_Q.Location = new Point(107, 193);
            bt_Q.Name = "bt_Q";
            bt_Q.Size = new Size(50, 50);
            bt_Q.TabIndex = 43;
            bt_Q.Text = "Q";
            bt_Q.UseVisualStyleBackColor = true;
            bt_Q.Click += bt_Q_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pnl_kb);
            Controls.Add(pnl);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            pnl.ResumeLayout(false);
            pnl.PerformLayout();
            pnl_kb.ResumeLayout(false);
            pnl_kb.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label lb_word1;
        private Label lb_word2;
        private Label lb_word3;
        private Label lb_word4;
        private Label lb_word5;
        private TextBox tb_1;
        private TextBox tb2;
        private TextBox tb3;
        private TextBox tb4;
        private TextBox tb5;
        private Button bt_play;
        private Panel pnl;
        private Panel pnl_kb;
        private Label lb_isi;
        private Label lb_isi_5;
        private Label lb_isi_4;
        private Label lb_isi_3;
        private Label lb_isi_2;
        private Label lb_isi1;
        private Button bt_M;
        private Button bt_N;
        private Button bt_B;
        private Button bt_V;
        private Button bt_C;
        private Button bt_Z;
        private Button bt_X;
        private Button bt_A;
        private Button bt_S;
        private Button bt_D;
        private Button bt_F;
        private Button bt_G;
        private Button bt_L;
        private Button bt_K;
        private Button bt_J;
        private Button bt_H;
        private Button bt_P;
        private Button bt_w;
        private Button bt_E;
        private Button bt_R;
        private Button bt_T;
        private Button bt_O;
        private Button bt_I;
        private Button bt_U;
        private Button bt_Y;
        private Button bt_Q;
        private Label lb_isi_1;
    }
}
